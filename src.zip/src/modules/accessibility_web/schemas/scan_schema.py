"""
scan_schema.py – Pydantic request schema for scan-related endpoints.
"""

from pydantic import BaseModel, Field, field_validator


class ScanCreateRequest(BaseModel):
    url: str = Field(..., min_length=1, max_length=2048)

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        v = v.strip()
        if not (v.startswith("http://") or v.startswith("https://")):
            raise ValueError("url must start with http:// or https://")
        return v
