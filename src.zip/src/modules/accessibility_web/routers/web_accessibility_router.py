"""
web_accessibility_router.py - FastAPI router for the Orion Web Accessibility
module.

Three resource slices are wired end-to-end so far:

    Websites:
        web_accessibility_router.py -> website_service.py
            -> web_accessibility_websites_model.py -> DB

    Pages (read-only listings - see page_service.py's module docstring for
    why there's no write endpoint):
        web_accessibility_router.py -> page_service.py
            -> web_accessibility_pages_model.py -> DB

    Scans (+ their issues):
        web_accessibility_router.py -> scan_service.py
            -> web_accessibility_pages_model.py -> DB (get-or-create per url)
            -> web_accessibility_scans_model.py -> DB
            -> web_accessibility_issues_model.py / web_accessibility_rules_model.py -> DB
              (joined, for GET /scans/{scan_id}/issues)

    The full chain is Website 1:N Page 1:N Scan 1:N Issue - see
    scan_service.py's module docstring for the rationale (a Page is a
    persistent entity a URL represents; a Scan is one run against it).

A website must be registered before it can be scanned. POST .../scan writes
a QUEUED scan row via scan_service.create_scan(), then hands the new scan's
id to scan_service.run_scan() as a FastAPI BackgroundTask - it runs after
the 202 response is sent, fetches the URL, evaluates it against the rule
checks in scan_service.RULE_CHECKS, and writes any findings as
WebAccessibilityIssuesModel rows before rolling the scan to COMPLETED/FAILED.
This is a lightweight static-HTML fetch + parse (stdlib html.parser), not a
headless-browser render - no such dependency is installed in this project.
The fetch itself goes through acquisition/url_guard.safe_fetch(), which
rejects a scan url whose host doesn't match the registered website (see
scan_service.create_scan - returns 400 immediately, no background task is
queued) and blocks the fetch (scan.status=BLOCKED) if the url or any
redirect hop it follows resolves to a private/reserved address that isn't
on settings.scan_private_ip_allowlist.
remediation_service.py, validation_service.py and report_service.py are
still empty stubs.

All endpoints below - website and scan/issue alike - return the same
{response_code, message, data, errors} envelope via build_response().
Scan/issue endpoints originally returned bare JSON bodies per an earlier
version of this slice's API contract; standardized on the envelope after
a review flagged the inconsistency, before any frontend/dashboard client
existed to depend on the old shape. POST .../scan's queued-scan summary
and the {items, total} issue/history listings now live under "data".

web_accessibility_issues rows are persistent defects, deduplicated across
scans of the same page, not one-row-per-scan snapshots - see
scan_service.py's module docstring ("Issue lifecycle / dedup") for the
matching key and what GET /scans/{scan_id}/issues does and doesn't show.

Endpoints (mounted under /api/v1/web-accessibility, see api_router.py):

    POST   /websites                       Register a website for scanning
    GET    /websites                       List registered websites
    GET    /websites/{website_id}          Get a single website
    PUT    /websites/{website_id}          Update a website
    DELETE /websites/{website_id}          Remove a website

    GET    /websites/{website_id}/pages    List a website's pages

    POST   /websites/{website_id}/scan     Queue a scan for a website
    GET    /websites/{website_id}/scan     Get a website's scan history
    GET    /pages/{page_id}/scans          Get a page's scan history
    GET    /scans/{scan_id}                Get a scan's status/results
    GET    /scans/{scan_id}/issues         List a scan's issues
                                            (filters: ?status=&severity=&rule_code=)
"""

from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from src.core.database import get_db
from src.core.logger import get_logger
from src.core.response import build_response
from src.modules.accessibility_web.schemas.scan_schema import ScanCreateRequest
from src.modules.accessibility_web.schemas.website_schema import (
    WebsiteCreate,
    WebsiteUpdate,
)
from src.modules.accessibility_web.services.page_service import PageService
from src.modules.accessibility_web.services.scan_service import ScanService
from src.modules.accessibility_web.services.website_Service import WebsiteService

router = APIRouter()
logger = get_logger(__name__)

website_service = WebsiteService()
page_service = PageService()
scan_service = ScanService()


# ==================== Website CRUD Endpoints ====================

@router.post("/websites", status_code=status.HTTP_201_CREATED)
def create_website(payload: WebsiteCreate, db: Session = Depends(get_db)):
    """Register a new website for accessibility scanning."""
    try:
        website = website_service.create_website(
            db=db,
            base_url=payload.base_url,
            name=payload.name,
            description=payload.description,
            environment=payload.environment,
            crawl_enabled=payload.crawl_enabled,
            crawl_frequency=payload.crawl_frequency,
            authentication_required=payload.authentication_required,
            authentication_type=payload.authentication_type,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    return build_response(
        response_code=status.HTTP_201_CREATED,
        message="Website registered successfully",
        data=website.to_dict(),
    )


@router.get("/websites")
def get_all_websites(
    db: Session = Depends(get_db),
    environment: Optional[str] = Query(None, description="Filter by environment, e.g. PRODUCTION"),
    crawl_enabled: Optional[bool] = Query(None, description="Filter by crawl_enabled"),
):
    """List registered websites, optionally filtered by environment and/or crawl_enabled."""
    websites = website_service.get_all_websites(
        db=db, environment=environment, crawl_enabled=crawl_enabled
    )
    return build_response(
        response_code=status.HTTP_200_OK,
        message="Websites retrieved successfully",
        data=[w.to_dict() for w in websites],
    )


@router.get("/websites/{website_id}")
def get_website(website_id: int, db: Session = Depends(get_db)):
    """Get a single website by ID."""
    website = website_service.get_website_by_id(db=db, website_id=website_id)
    if not website:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Website not found")

    return build_response(
        response_code=status.HTTP_200_OK,
        message="Website retrieved successfully",
        data=website.to_dict(),
    )


@router.put("/websites/{website_id}")
def update_website(website_id: int, payload: WebsiteUpdate, db: Session = Depends(get_db)):
    """Update a website. Only fields present in the payload are changed."""
    try:
        website = website_service.update_website(
            db=db,
            website_id=website_id,
            **payload.model_dump(exclude_unset=True),
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    if not website:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Website not found")

    return build_response(
        response_code=status.HTTP_200_OK,
        message="Website updated successfully",
        data=website.to_dict(),
    )


@router.delete("/websites/{website_id}")
def delete_website(website_id: int, db: Session = Depends(get_db)):
    """Delete a website."""
    success = website_service.delete_website(db=db, website_id=website_id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Website not found")

    return build_response(
        response_code=status.HTTP_200_OK,
        message="Website deleted successfully",
        data={"id": website_id},
    )


# ==================== Page Endpoints ====================

@router.get("/websites/{website_id}/pages")
def get_website_pages(website_id: int, db: Session = Depends(get_db)):
    """
    List a website's pages. A page is created implicitly the first time a
    URL on this website is scanned (see scan_service._get_or_create_page) -
    there's no separate "add a page" endpoint yet.
    """
    pages = page_service.get_pages_for_website(db=db, website_id=website_id)
    if pages is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Website not found")

    items = [p.to_dict() for p in pages]
    return build_response(
        response_code=status.HTTP_200_OK,
        message="Website pages retrieved successfully",
        data={"items": items, "total": len(items)},
    )


# ==================== Scan & Issues Endpoints ====================

@router.post("/websites/{website_id}/scan", status_code=status.HTTP_202_ACCEPTED)
def create_scan(
    website_id: int,
    payload: ScanCreateRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    """
    Queue a scan for one page of a website and kick off the actual fetch +
    evaluation in the background. Returns immediately with status=QUEUED -
    poll GET /scans/{scan_id} for progress (QUEUED -> RUNNING ->
    COMPLETED/FAILED/BLOCKED - BLOCKED means url_guard rejected the url or
    a redirect target, see acquisition/url_guard.py).
    """
    try:
        scan = scan_service.create_scan(db=db, website_id=website_id, url=payload.url)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    if not scan:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Website not found")

    background_tasks.add_task(scan_service.run_scan, scan.id)

    return build_response(
        response_code=status.HTTP_202_ACCEPTED,
        message="Scan queued successfully",
        data={
            "scan_id": scan.id,
            "website_id": scan.website_id,
            "url": scan.url,
            "status": scan.status,
        },
    )


@router.get("/scans/{scan_id}")
def get_scan(scan_id: int, db: Session = Depends(get_db)):
    """Get a scan's current status and results."""
    scan = scan_service.get_scan_by_id(db=db, scan_id=scan_id)
    if not scan:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found")

    return build_response(
        response_code=status.HTTP_200_OK,
        message="Scan retrieved successfully",
        data=scan.to_dict(),
    )


@router.get("/scans/{scan_id}/issues")
def get_scan_issues(
    scan_id: int,
    db: Session = Depends(get_db),
    status_filter: Optional[str] = Query(
        None, alias="status", description="Filter by issue status, e.g. OPEN"
    ),
    severity: Optional[str] = Query(None, description="Filter by severity, e.g. CRITICAL"),
    rule_code: Optional[str] = Query(None, description="Filter by rule code, e.g. IMG-001"),
):
    """
    List issues this scan originally found or has most recently reconfirmed,
    joined with rule metadata, optionally filtered. Issues are persistent
    defects, not per-scan snapshots - re-scanning the same page doesn't
    create duplicate rows for a still-open problem (see scan_service.py's
    module docstring, "Issue lifecycle / dedup"); each item's status/
    times_seen/resolved_at reflect its CURRENT state, not a snapshot frozen
    at this scan's run time.
    """
    issues = scan_service.get_scan_issues(
        db=db,
        scan_id=scan_id,
        status=status_filter,
        severity=severity,
        rule_code=rule_code,
    )
    if issues is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found")

    return build_response(
        response_code=status.HTTP_200_OK,
        message="Scan issues retrieved successfully",
        data={"items": issues, "total": len(issues)},
    )


@router.get("/websites/{website_id}/scan")
def get_website_scan_history(website_id: int, db: Session = Depends(get_db)):
    """List a website's scan history (every page), most recent first."""
    scans = scan_service.get_scans_for_website(db=db, website_id=website_id)
    if scans is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Website not found")

    items = [_scan_history_item(s) for s in scans]
    return build_response(
        response_code=status.HTTP_200_OK,
        message="Website scan history retrieved successfully",
        data={"items": items, "total": len(items)},
    )


@router.get("/pages/{page_id}/scans")
def get_page_scan_history(page_id: int, db: Session = Depends(get_db)):
    """List one page's scan history, most recent first."""
    scans = page_service.get_scans_for_page(db=db, page_id=page_id)
    if scans is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Page not found")

    items = [_scan_history_item(s) for s in scans]
    return build_response(
        response_code=status.HTTP_200_OK,
        message="Page scan history retrieved successfully",
        data={"items": items, "total": len(items)},
    )


def _scan_history_item(scan) -> dict:
    """Shared trimmed shape for both scan-history listings above."""
    return {
        "id": scan.id,
        "page_id": scan.page_id,
        "url": scan.url,
        "status": scan.status,
        "total_issues": scan.total_issues,
        "accessibility_score": float(scan.accessibility_score) if scan.accessibility_score is not None else None,
        "completed_at": scan.completed_at,
    }
