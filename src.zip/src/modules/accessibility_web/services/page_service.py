"""
page_service.py - Read-only access for the web_accessibility_pages
resource.

Pages are created implicitly by scan_service.create_scan()'s
get-or-create (_get_or_create_page) the first time a URL is scanned -
there's no write path here, deliberately: a page coming into existence is
a side effect of scanning it (or, eventually, of a crawler discovering
it), not something a client creates directly. This service only covers
the two listing endpoints built on top of that: a website's pages, and a
page's scan history. See scan_service.py's module docstring for the full
Website 1:N Page 1:N Scan 1:N Issue picture.
"""

from typing import Optional

from sqlalchemy.orm import Session

from src.core.logger import get_logger
from src.modules.accessibility_web.models.web_accessibility_pages_model import (
    WebAccessibilityPagesModel,
)
from src.modules.accessibility_web.models.web_accessibility_scans_model import (
    WebAccessibilityScansModel,
)
from src.modules.accessibility_web.models.web_accessibility_websites_model import (
    WebAccessibilityWebsiteModel,
)

logger = get_logger(__name__)


class PageService:

    def get_page_by_id(
        self, db: Session, page_id: int
    ) -> Optional[WebAccessibilityPagesModel]:
        """Get a single page by ID."""
        return (
            db.query(WebAccessibilityPagesModel)
            .filter(WebAccessibilityPagesModel.id == page_id)
            .first()
        )

    def get_pages_for_website(self, db: Session, website_id: int):
        """
        List a website's pages, oldest first. Returns None if the website
        doesn't exist.
        """
        website = (
            db.query(WebAccessibilityWebsiteModel)
            .filter(WebAccessibilityWebsiteModel.id == website_id)
            .first()
        )
        if not website:
            return None

        return (
            db.query(WebAccessibilityPagesModel)
            .filter(WebAccessibilityPagesModel.website_id == website_id)
            .order_by(WebAccessibilityPagesModel.id.asc())
            .all()
        )

    def get_scans_for_page(self, db: Session, page_id: int):
        """
        List a page's scan history, most recent first. Returns None if the
        page doesn't exist.
        """
        page = self.get_page_by_id(db, page_id)
        if not page:
            return None

        return (
            db.query(WebAccessibilityScansModel)
            .filter(WebAccessibilityScansModel.page_id == page_id)
            .order_by(WebAccessibilityScansModel.id.desc())
            .all()
        )
