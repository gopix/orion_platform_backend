"""
DocumentRemediatorAgent - Remediates document-level PDF accessibility issues.

Handles the following auto-fixable rules from DocumentAccessibilityAgent:

    DOC_HAS_TITLE         → pdf_doc.SetInfo("Title", ...) + XMP dc:title sync
    DOC_HAS_LANGUAGE      → pdf_doc.SetLang("en-US")          (default when none set)
    DOC_HAS_METADATA      → pdf_doc.SetInfo(key, value)        (fills missing Title/Author/Subject)
    DOC_IS_TAGGED         → pdf_doc.AddTags(PdfTagsParams())   (auto-tags untagged document)
    DOC_PDFUA_DECLARATION → pdf_doc.SetPdfStandard(...)        (enables PDF/UA compliance flag)

All modifications are **in-place** on the open ``pdf_doc`` object.
The caller (``AccessibilityRemediationPipeline``) saves the document after all
remediations are complete.

XMP note (DOC_HAS_TITLE):
    Adobe Acrobat's "Title" accessibility check reads from the XMP metadata
    stream (dc:title), NOT just the Info dictionary /Title key.  PDFix
    SetInfo() updates the Info dict; we additionally patch the raw XMP stream
    so Acrobat's checker sees the value.
"""

from __future__ import annotations

from typing import Any

from src.core.logger import get_logger

from .base_remediator_agent import BaseRemediatorAgent, RemediationResult

_MODULE_VERSION = "document_remediator_agent v2-schedule-pdfua"
print(f"[DEBUG] {_MODULE_VERSION} loaded", flush=True) 

logger = get_logger(__name__)

# PDF/UA part number — PDF/UA-1 is part 1, PDF/UA-2 is part 2.
# We target PDF/UA-1 which is the widely adopted standard.
_PDFUA_PART = 1


class DocumentRemediatorAgent(BaseRemediatorAgent):
    """Remediates document-level accessibility issues using PDFix SDK."""

    agent_name = "Document Remediator Agent"

    supported_rules: set[str] = {
        "DOC_HAS_TITLE",
        "DOC_HAS_LANGUAGE",
        "DOC_HAS_METADATA",
        "DOC_IS_TAGGED",
        "DOC_PDFUA_DECLARATION",
    }

    DEFAULT_LANGUAGE = "en-US"

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def remediate(
        self,
        issue: dict[str, Any],
        context: dict[str, Any],
    ) -> RemediationResult:
        rule_id = issue.get("rule_id", "")
        handlers = {
            "DOC_HAS_TITLE": self._fix_title,
            "DOC_HAS_LANGUAGE": self._fix_language,
            "DOC_HAS_METADATA": self._fix_metadata,
            "DOC_IS_TAGGED": self._fix_tagging,
            "DOC_PDFUA_DECLARATION": self._fix_pdfua,
        }
        handler = handlers.get(rule_id)
        if handler is None:
            return self._result(
                rule_id, False, "no_handler",
                error=f"DocumentRemediatorAgent: unsupported rule '{rule_id}'",
            )
        return handler(rule_id, context)

    # ------------------------------------------------------------------
    # DOC_HAS_TITLE
    # ------------------------------------------------------------------

    def _fix_title(self, rule_id: str, context: dict[str, Any]) -> RemediationResult:
        pdf_doc = context.get("pdf_doc")
        if pdf_doc is None:
            return self._result(rule_id, False, "fix_title", error="pdf_doc not in context")

        try:
            current_title = (pdf_doc.GetInfo("Title") or "").strip()
            if current_title:
                return self._result(
                    rule_id, True, "fix_title",
                    changes_made=[f"Title already set to '{current_title}' – no change needed"],
                )

            raw_name = context.get("document_name") or ""
            title = (
                raw_name.rsplit(".", 1)[0].replace("_", " ").replace("-", " ").strip()
                or "Untitled Document"
            )

            changes: list[str] = []
            pdf_doc.SetInfo("Title", title)
            changes.append(f"Set Info /Title → '{title}'")

            xmp_warning = _patch_xmp_title(pdf_doc, title)
            if xmp_warning:
                changes.append(f"XMP dc:title warning: {xmp_warning}")
            else:
                changes.append(f"Patched XMP dc:title → '{title}'")

            return self._result(rule_id, True, "fix_title", changes_made=changes)

        except Exception as exc:
            logger.exception("DOC_HAS_TITLE remediation failed")
            return self._result(rule_id, False, "fix_title", error=str(exc))

    # ------------------------------------------------------------------
    # DOC_HAS_LANGUAGE
    # ------------------------------------------------------------------

    def _fix_language(self, rule_id: str, context: dict[str, Any]) -> RemediationResult:
        pdf_doc = context.get("pdf_doc")
        if pdf_doc is None:
            return self._result(rule_id, False, "fix_language", error="pdf_doc not in context")

        try:
            current_lang = pdf_doc.GetLang()
            if current_lang and current_lang.strip():
                return self._result(
                    rule_id, True, "fix_language",
                    changes_made=[f"Language already set to '{current_lang}' – no change needed"],
                )

            pdf_doc.SetLang(self.DEFAULT_LANGUAGE)
            return self._result(
                rule_id, True, "fix_language",
                changes_made=[f"Set document language to '{self.DEFAULT_LANGUAGE}'"],
            )
        except Exception as exc:
            logger.exception("DOC_HAS_LANGUAGE remediation failed")
            return self._result(rule_id, False, "fix_language", error=str(exc))

    # ------------------------------------------------------------------
    # DOC_HAS_METADATA
    # ------------------------------------------------------------------

    def _fix_metadata(self, rule_id: str, context: dict[str, Any]) -> RemediationResult:
        pdf_doc = context.get("pdf_doc")
        if pdf_doc is None:
            return self._result(rule_id, False, "fix_metadata", error="pdf_doc not in context")

        changes: list[str] = []
        try:
            if not (pdf_doc.GetInfo("Title") or "").strip():
                title = context.get("document_name") or "Untitled Document"
                pdf_doc.SetInfo("Title", title)
                changes.append(f"Set Title → '{title}'")

            if not (pdf_doc.GetInfo("Author") or "").strip():
                pdf_doc.SetInfo("Author", "Unknown Author")
                changes.append("Set Author → 'Unknown Author'")

            if not (pdf_doc.GetInfo("Subject") or "").strip():
                pdf_doc.SetInfo("Subject", "PDF Document")
                changes.append("Set Subject → 'PDF Document'")

            if not changes:
                return self._result(
                    rule_id, True, "fix_metadata",
                    changes_made=["All metadata fields already populated – no change needed"],
                )
            return self._result(rule_id, True, "fix_metadata", changes_made=changes)

        except Exception as exc:
            logger.exception("DOC_HAS_METADATA remediation failed")
            return self._result(rule_id, False, "fix_metadata", changes_made=changes, error=str(exc))

    # ------------------------------------------------------------------
    # DOC_IS_TAGGED
    # ------------------------------------------------------------------

    def _fix_tagging(self, rule_id: str, context: dict[str, Any]) -> RemediationResult:
        pdf_doc = context.get("pdf_doc")
        if pdf_doc is None:
            return self._result(rule_id, False, "fix_tagging", error="pdf_doc not in context")

        try:
            struct_tree = pdf_doc.GetStructTree()
            if struct_tree:
                return self._result(
                    rule_id, True, "fix_tagging",
                    changes_made=["Document already has a structure tree – no tagging needed"],
                )

            from pdfixsdk.Pdfix import PdfTagsParams  # type: ignore[import]

            tag_params = PdfTagsParams()
            success = bool(pdf_doc.AddTags(tag_params))

            if not success:
                return self._result(
                    rule_id, False, "fix_tagging",
                    error="PDFix AddTags() returned False – document may be encrypted or corrupt",
                )

            self._invalidate_cache(
                context,
                "headings_by_pdf",
                "images_by_pdf",
                "tables_by_pdf",
                "tree_structure_by_pdf",
                "reading_order_document_mode",
            )

            return self._result(
                rule_id, True, "fix_tagging",
                changes_made=["Applied automatic PDF structure tagging via PDFix AddTags()"],
            )

        except ImportError:
            return self._result(
                rule_id, False, "fix_tagging",
                error="pdfixsdk not installed – cannot add tags",
            )
        except Exception as exc:
            logger.exception("DOC_IS_TAGGED remediation failed")
            return self._result(rule_id, False, "fix_tagging", error=str(exc))

    # ------------------------------------------------------------------
    # DOC_PDFUA_DECLARATION
    # ------------------------------------------------------------------

    def _fix_pdfua(self, rule_id: str, context: dict[str, Any]) -> RemediationResult:
        """Schedule PDF/UA-1 XMP marker injection as a post-processing step.

        Why scheduling instead of in-memory PDFix SDK calls?
            - SetPdfStandard(flags, part) fails: PDFix SWIG expects a C enum for 'part'
            - SetMetadata(data) also fails: PDFix 9.x SWIG expects (data, length) signature
            The pipeline's _set_display_doc_title step already injects pdfuaid:part=1
            into the SAVED file's XMP stream via pypdf (no SWIG calls required).
            We mark this as a scheduled fix so the pipeline correctly reconciles it
            after post-processing runs.
        """
        print("[DEBUG v2] _fix_pdfua called — NEW scheduling code active", flush=True)
        context["_pdfua_fix_scheduled"] = True
        return self._result(
            rule_id, True, "schedule_pdfua_fix",
            changes_made=[
                "Scheduled PDF/UA-1 XMP marker injection (pdfuaid:part=1) "
                "as a post-processing step. The _set_display_doc_title step "
                "injects this into the saved file's XMP stream via pypdf."
            ],
        )


# ---------------------------------------------------------------------------
# Module-level XMP helper
# ---------------------------------------------------------------------------

def _patch_xmp_title(pdf_doc: Any, title: str) -> str | None:
    import re as _re

    try:
        xmp_bytes: bytes | None = None
        if hasattr(pdf_doc, "GetMetadata"):
            raw = pdf_doc.GetMetadata()
            if isinstance(raw, (bytes, bytearray)):
                xmp_bytes = bytes(raw)
            elif isinstance(raw, str):
                xmp_bytes = raw.encode("utf-8")

        if not xmp_bytes:
            xmp_bytes = _minimal_xmp_packet(title)
            if hasattr(pdf_doc, "SetMetadata"):
                pdf_doc.SetMetadata(xmp_bytes)
            return None

        xmp_str = xmp_bytes.decode("utf-8", errors="replace")

        escaped_title = (
            title
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )

        dc_title_block = (
            f'<dc:title><rdf:Alt><rdf:li xml:lang="x-default">'
            f'{escaped_title}</rdf:li></rdf:Alt></dc:title>'
        )

        if "<dc:title>" in xmp_str:
            xmp_str = _re.sub(
                r"<dc:title>.*?</dc:title>",
                dc_title_block,
                xmp_str,
                flags=_re.DOTALL,
            )
        else:
            xmp_str = xmp_str.replace(
                "</rdf:Description>",
                f"  {dc_title_block}\n</rdf:Description>",
                1,
            )

        new_xmp_bytes = xmp_str.encode("utf-8")
        if hasattr(pdf_doc, "SetMetadata"):
            pdf_doc.SetMetadata(new_xmp_bytes)
            return None
        else:
            return "pdf_doc.SetMetadata() not available – XMP not updated"

    except Exception as exc:
        return f"XMP patch failed ({exc}); Info /Title was still set"


def _minimal_xmp_packet(title: str) -> bytes:
    escaped = (
        title
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
    packet = (
        '<?xpacket begin="\xef\xbb\xbf" id="W5M0MpCehiHzreSzNTczkc9d"?>'
        '<x:xmpmeta xmlns:x="adobe:ns:meta/">'
        '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
        '<rdf:Description rdf:about="" xmlns:dc="http://purl.org/dc/elements/1.1/">'
        f'<dc:title><rdf:Alt><rdf:li xml:lang="x-default">{escaped}</rdf:li></rdf:Alt></dc:title>'
        '</rdf:Description>'
        '</rdf:RDF>'
        '</x:xmpmeta>'
        '<?xpacket end="w"?>'
    )
    return packet.encode("utf-8")
