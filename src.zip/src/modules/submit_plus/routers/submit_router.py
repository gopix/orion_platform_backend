from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from src.core.database import get_db
from src.modules.submit_plus.controllers.submit_controller import create_manuscript
from src.modules.submit_plus.schemas.submit_schema import SubmitRequest

router = APIRouter(prefix="/submit", tags=["Submit+"])

@router.get("/test")
async def test_submit():
    return {"message": "Submit Plus router is working"}

@router.post("/manuscripts")
def create(payload: SubmitRequest, db: Session = Depends(get_db)):
    return create_manuscript(payload, db)