class BaseEngine:

    def run(self, manuscript) -> dict:
        raise NotImplementedError