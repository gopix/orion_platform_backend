# submit_controller.py

from sqlalchemy.orm import Session
from src.modules.submit_plus.services.submit_service import create_manuscript_service


def create_manuscript(payload, db: Session):

    # Step 1: call service
    manuscript = create_manuscript_service(db, payload)

    # Step 2: trigger pipeline (later)
    # trigger_pipeline(manuscript.id)

    # Step 3: response formatting
    return {
        "message": "Manuscript submitted successfully",
        "manuscript_id": manuscript.id
    }