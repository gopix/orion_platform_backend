# submit_service.py

from src.modules.submit_plus.models.manuscript_model import Manuscript


def create_manuscript_service(db, payload):

    manuscript = Manuscript(
        title=payload.title,
        author=payload.author,
        status="Submitted"
    )

    db.add(manuscript)
    db.commit()
    db.refresh(manuscript)

    return manuscript