-- ==========================================
-- ORION PLATFORM DATABASE SCHEMA (corrected)
--   * de-duplicated book_forge_prompt_* tables (were defined 2-3x)
--   * book_forge_category created BEFORE tables that FK to it
--   * book_forge_prompt_templates keeps description + active_version
--     (required by the Prompt Engine) AND category_id (FK to category)
-- ==========================================

CREATE DATABASE IF NOT EXISTS orion_db;
USE orion_db;

-- ==========================================
-- ORGANIZATIONS / ROLES / USERS
-- ==========================================
CREATE TABLE organizations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    organization_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NULL,
    updated_by INT NULL
);

CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(255) NOT NULL,
    role_description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO roles(role_name, role_description, is_active) VALUES
('USER', 'normal user', 1),
('ADMIN', 'administrator', 1),
('BookForge_SME', 'book forge SME', 1),
('BookForge_EDITOR', 'book forge editor', 1);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    organization_id INT,
    role_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NULL,
    updated_by INT NULL,
    FOREIGN KEY (organization_id) REFERENCES organizations(id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- ==========================================
-- PUBLISHING / EDITOR / SALES (unchanged)
-- ==========================================
CREATE TABLE manuscripts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    organization_id INT NOT NULL,
    title VARCHAR(500),
    author VARCHAR(255),
    status VARCHAR(50) DEFAULT 'Submitted',
    file_path VARCHAR(512),
    file_name VARCHAR(255),
    file_size INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NULL,
    updated_by INT NULL,
    FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

CREATE TABLE editor_analysis_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    manuscript_id INT NOT NULL,
    analysis_json JSON,
    model_version VARCHAR(50),
    processing_time_seconds DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NULL,
    updated_by INT NULL,
    FOREIGN KEY (manuscript_id) REFERENCES manuscripts(id)
);

CREATE TABLE ai_agent_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    manuscript_id INT,
    agent_name VARCHAR(100),
    input_text TEXT,
    output_text TEXT,
    latency_ms INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (manuscript_id) REFERENCES manuscripts(id)
);

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    subject VARCHAR(100),
    isbn VARCHAR(50),
    price DECIMAL(10,2),
    organization_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

CREATE TABLE inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    warehouse VARCHAR(100),
    quantity INT,
    organization_id INT,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(id)
);

CREATE TABLE distributors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    city VARCHAR(100),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    distributor_id INT,
    quantity INT,
    total_amount DECIMAL(10,2),
    sale_date DATE,
    organization_id INT,
    FOREIGN KEY (book_id) REFERENCES books(id),
    FOREIGN KEY (distributor_id) REFERENCES distributors(id)
);

CREATE TABLE returns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    distributor_id INT,
    quantity INT,
    return_date DATE,
    organization_id INT,
    FOREIGN KEY (book_id) REFERENCES books(id),
    FOREIGN KEY (distributor_id) REFERENCES distributors(id)
);

CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    distributor_id INT,
    amount DECIMAL(10,2),
    payment_date DATE,
    organization_id INT,
    FOREIGN KEY (distributor_id) REFERENCES distributors(id)
);

CREATE TABLE book_structure_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    organization_id INT NOT NULL,
    book_id INT NULL,
    template_name VARCHAR(255),
    structure_json JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id),
    FOREIGN KEY (book_id) REFERENCES books(id)
);

-- ==========================================
-- ACCESSIBILITY
-- ==========================================
CREATE TABLE master_accessibility_check (
    check_id INT AUTO_INCREMENT PRIMARY KEY,
    check_code VARCHAR(100) NOT NULL UNIQUE,
    check_name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL,
    default_priority VARCHAR(10) NOT NULL,
    wcag_reference VARCHAR(50),
    pdfua_reference VARCHAR(50),
    remediation_guidance TEXT,
    agent_code VARCHAR(100),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (default_priority IN ('HIGH', 'MEDIUM', 'LOW'))
);

CREATE TABLE org_project_accessibility_check (
    id INT AUTO_INCREMENT PRIMARY KEY,
    organization_id INT NOT NULL,
    project_id VARCHAR(100) NULL,
    master_check_id INT NOT NULL,
    check_code VARCHAR(100) NOT NULL,
    check_name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL,
    default_priority VARCHAR(10) NOT NULL,
    wcag_reference VARCHAR(50),
    pdfua_reference VARCHAR(50),
    remediation_guidance TEXT,
    agent_code VARCHAR(100),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_org_project_check_code (organization_id, project_id, check_code),
    FOREIGN KEY (organization_id) REFERENCES organizations(id),
    FOREIGN KEY (master_check_id) REFERENCES master_accessibility_check(check_id),
    CHECK (default_priority IN ('HIGH', 'MEDIUM', 'LOW'))
);

CREATE TABLE accessibility_mis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    file_executed VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    execution_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==========================================
-- BOOK FORGE
--   NOTE: category is created first (projects + prompt_templates FK to it).
-- ==========================================
CREATE TABLE book_forge_category (
    id                   BIGINT AUTO_INCREMENT PRIMARY KEY,
    category_name        VARCHAR(100) NOT NULL UNIQUE,
    category_description VARCHAR(500) NULL,
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Workflow status master. Created + seeded BEFORE book_forge_projects, which
-- FKs book_status -> status_name (and defaults to 'draft', so that row must exist).
CREATE TABLE IF NOT EXISTS book_forge_project_status (
    status_id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    status_name        VARCHAR(50)  NOT NULL UNIQUE,      -- internal enum, e.g. 'draft'
    status_label       VARCHAR(100) NOT NULL,             -- UI label,       e.g. 'Draft'
    status_description VARCHAR(255) NULL,                 -- when this status applies
    sort_order         INT          NOT NULL DEFAULT 0,   -- display / progression order
    created_by         BIGINT       NULL,
    updated_by         BIGINT       NULL,
    created_at         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO book_forge_project_status
    (status_name, status_label, status_description, sort_order)
VALUES
    ('draft',                'Draft',                   'Project created, no sources yet',                     1),
    ('sources_added',        'Sources Added',           'At least one source uploaded (any type)',             2),
    ('building_knowledge',   'Building Knowledge Base', 'Ingestion running (parse -> chunk -> embed -> store)', 3),
    ('knowledge_ready',      'Knowledge Base Ready',    'Vectors stored, ready to generate',                   4),
    ('generating_blueprint', 'Generating Blueprint',    'LLM generation running',                              5),
    ('blueprint_ready',      'Blueprint Ready',         'Blueprint generated & saved',                         6),
    ('failed',               'Failed',                  'Any step errored',                                    99)
ON DUPLICATE KEY UPDATE
    status_label       = VALUES(status_label),
    status_description = VALUES(status_description),
    sort_order         = VALUES(sort_order);

CREATE TABLE book_forge_projects (
    id                      BIGINT AUTO_INCREMENT PRIMARY KEY,
    book_title              VARCHAR(255) NOT NULL,
    category_id             BIGINT,
    book_subject            VARCHAR(255),
    target_audience         VARCHAR(255),
    language_code           VARCHAR(10),
    expected_pages          INT,
    chapter_count           INT,
    publisher_name          VARCHAR(255),
    edition                 VARCHAR(50),
    primary_output_format   VARCHAR(50),
    book_description        TEXT,
    submission_deadline     DATE,
    book_status             VARCHAR(50) NOT NULL DEFAULT 'draft',
    created_by              BIGINT,
    created_at              DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at              DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted              BOOLEAN DEFAULT FALSE,
    KEY ix_bfp_category (category_id),
    KEY ix_bfp_status (book_status),
    CONSTRAINT fk_project_category FOREIGN KEY (category_id)
        REFERENCES book_forge_category (id),
    CONSTRAINT fk_project_status FOREIGN KEY (book_status)
        REFERENCES book_forge_project_status (status_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE book_forge_documents (
    id                BIGINT AUTO_INCREMENT PRIMARY KEY,
    project_id        BIGINT NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    stored_filename   VARCHAR(255) NOT NULL,
    file_path         VARCHAR(512) NOT NULL,
    file_extension    VARCHAR(20),
    mime_type         VARCHAR(150),
    file_size         BIGINT,
    document_type     VARCHAR(50),
    created_by        BIGINT NOT NULL,
    created_at        TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted        BOOLEAN NOT NULL DEFAULT FALSE,
    INDEX idx_project_id (project_id),
    FOREIGN KEY (project_id) REFERENCES book_forge_projects (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE book_forge_document_processing (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    project_id          BIGINT NOT NULL,
    document_id         BIGINT NOT NULL,
    processing_stage    VARCHAR(50) NOT NULL,
    processing_status   VARCHAR(30) DEFAULT 'PENDING',
    started_at          DATETIME,
    completed_at        DATETIME,
    error_message       TEXT,
    processing_version  VARCHAR(30),
    created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES book_forge_documents(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Prompt Engine: templates carry description + active_version (used by the code)
-- and an optional category_id FK to the category master.
CREATE TABLE book_forge_prompt_templates (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(255) NOT NULL UNIQUE,
    category_id    BIGINT NULL,
    description    TEXT,
    active_version INT,
    status         VARCHAR(30) NOT NULL DEFAULT 'draft',
    created_by     BIGINT,
    created_at     TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY ix_pt_category (category_id),
    CONSTRAINT fk_pt_category FOREIGN KEY (category_id) REFERENCES book_forge_category(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE book_forge_prompt_versions (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    template_id   BIGINT NOT NULL,
    version       INT NOT NULL,
    template_text TEXT NOT NULL,
    model         VARCHAR(100),
    temperature   FLOAT,
    max_tokens    INT,
    status        VARCHAR(30) NOT NULL DEFAULT 'draft',
    created_by    BIGINT,
    created_at    TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_pv_template (template_id),
    CONSTRAINT fk_pv_template FOREIGN KEY (template_id) REFERENCES book_forge_prompt_templates(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE book_forge_prompt_variables (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    template_id   BIGINT NOT NULL,
    name          VARCHAR(100) NOT NULL,
    type          VARCHAR(30) NOT NULL DEFAULT 'string',
    required      TINYINT(1) NOT NULL DEFAULT 1,
    default_value TEXT,
    description   TEXT,
    KEY ix_pvar_template (template_id),
    CONSTRAINT fk_pvar_template FOREIGN KEY (template_id) REFERENCES book_forge_prompt_templates(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE book_forge_prompt_executions (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(64),
    prompt_id       BIGINT,
    version         INT,
    provider        VARCHAR(50),
    model           VARCHAR(100),
    rendered_prompt TEXT,
    response        TEXT,
    input_tokens    INT,
    output_tokens   INT,
    latency_ms      FLOAT,
    cost            FLOAT,
    status          VARCHAR(30),
    created_at      TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_pe_request (request_id),
    KEY ix_pe_prompt (prompt_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE book_forge_blueprints (
    id             BIGINT       NOT NULL AUTO_INCREMENT,
    project_id     BIGINT       NOT NULL,
    version        INT          NOT NULL DEFAULT 1,
    title          VARCHAR(255) NULL,
    description    TEXT         NULL,
    blueprint_json JSON         NOT NULL,
    status         VARCHAR(30)  NOT NULL DEFAULT 'generated',
    created_by     BIGINT       NULL,
    created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted     TINYINT(1)   NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY ix_bfb_project_id (project_id),
    KEY ix_bfb_status (status),
    UNIQUE KEY uq_bfb_project_version (project_id, version),
    CONSTRAINT fk_bfb_project FOREIGN KEY (project_id) REFERENCES book_forge_projects(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================
-- SAMPLE DATA
-- ==========================================
INSERT INTO organizations(organization_name) VALUES ('Orion'), ('Elsevier'), ('Wiley');

INSERT INTO users(user_name, email, password_hash, organization_id, role_id)
VALUES ('Test User', 'test@gmail.com', '12345678', 1, 1);

INSERT INTO books (title, subject, isbn, price) VALUES
('Math Class 10', 'Math', 'ISBN001', 250),
('Science Class 10', 'Science', 'ISBN002', 300),
('Hindi Vyakaran', 'Hindi', 'ISBN003', 200);

INSERT INTO distributors (name, city, phone) VALUES
('Rama Book Depot', 'Meerut', '9876543210'),
('Goyal Bros', 'Meerut', '9123456780'),
('Patna Distributors', 'Patna', '9988776655');


CREATE TABLE web_accessibility_websites (
    id BIGINT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    base_url VARCHAR(2048) NOT NULL,
    description VARCHAR(1000),
    accessibility_status VARCHAR(50) NOT NULL DEFAULT 'UNKNOWN',
    environment VARCHAR(50) NOT NULL DEFAULT 'PRODUCTION',
    crawl_enabled TINYINT(1) NOT NULL DEFAULT 0,
    crawl_frequency VARCHAR(50),
    authentication_required TINYINT(1) NOT NULL DEFAULT 0,
    authentication_type VARCHAR(50),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_scan_at TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (id),
    INDEX idx_web_accessibility_websites_status (accessibility_status),
    INDEX idx_web_accessibility_websites_environment (environment)
);

CREATE TABLE web_accessibility_scans (
    id BIGINT NOT NULL AUTO_INCREMENT,
    website_id BIGINT NOT NULL,
    url VARCHAR(2048) NOT NULL,
    title VARCHAR(500),
    status VARCHAR(50) NOT NULL DEFAULT 'QUEUED',
    http_status INT,
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    total_issues INT NOT NULL DEFAULT 0,
    accessibility_score DECIMAL(5,2),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_web_accessibility_scans_website (website_id),
    INDEX idx_web_accessibility_scans_status (status),
    INDEX idx_web_accessibility_scans_url (url(255))
);
CREATE TABLE web_accessibility_rules (
    id BIGINT NOT NULL AUTO_INCREMENT,
    rule_code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    wcag_criterion VARCHAR(20) NOT NULL,
    wcag_level VARCHAR(10) NOT NULL,
    category VARCHAR(100),
    severity VARCHAR(50),
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE INDEX uk_web_accessibility_rules_code (rule_code)
);

CREATE TABLE web_accessibility_issues (
    id BIGINT NOT NULL AUTO_INCREMENT,
    scan_id BIGINT NOT NULL,
    page_id BIGINT NOT NULL,
    rule_id BIGINT NOT NULL,
    severity VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'OPEN',
    element_selector VARCHAR(2000),
    html_snippet TEXT,
    message VARCHAR(2000),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_web_accessibility_issues_scan (scan_id),
    INDEX idx_web_accessibility_issues_page (page_id),
    INDEX idx_web_accessibility_issues_rule (rule_id),
    INDEX idx_web_accessibility_issues_status (status)
);


INSERT INTO web_accessibility_rules
    (rule_code, name, wcag_criterion, wcag_level, category, severity)
VALUES
-- Images
('IMG-001', 'Images must have alternative text',
 '1.1.1', 'A', 'IMAGES', 'CRITICAL'),
('IMG-002', 'Decorative images must be marked as decorative',
 '1.1.1', 'A', 'IMAGES', 'SERIOUS'),
('IMG-003', 'Image links must have an accessible name',
 '1.1.1', 'A', 'IMAGES', 'SERIOUS'),
-- Page Structure / Headings
('HDR-001', 'Page must have a descriptive title',
 '2.4.2', 'A', 'HEADINGS', 'SERIOUS'),
('HDR-002', 'Headings must follow a logical hierarchy',
 '1.3.1', 'A', 'HEADINGS', 'SERIOUS'),
('HDR-003', 'Heading elements must contain meaningful text',
 '1.3.1', 'A', 'HEADINGS', 'SERIOUS'),
-- Language
('LANG-001', 'Page must have a valid language declaration',
 '3.1.1', 'A', 'LANGUAGE', 'SERIOUS'),
-- Links
('LINK-001', 'Links must have an accessible name',
 '2.4.4', 'A', 'LINKS', 'SERIOUS'),
('LINK-002', 'Links must have meaningful link text',
 '2.4.4', 'A', 'LINKS', 'SERIOUS'),
-- Forms
('FORM-001', 'Form controls must have accessible labels',
 '1.3.1', 'A', 'FORMS', 'CRITICAL'),
('FORM-002', 'Form inputs must have an accessible name',
 '4.1.2', 'A', 'FORMS', 'CRITICAL'),
('FORM-003', 'Required form fields must be programmatically identified',
 '3.3.2', 'A', 'FORMS', 'SERIOUS'),
('FORM-004', 'Form errors must be identified and described',
 '3.3.1', 'A', 'FORMS', 'SERIOUS');
-- Ph-2

INSERT INTO web_accessibility_rules
    (rule_code, name, wcag_criterion, wcag_level, category, severity)
VALUES
-- Landmarks / Structure
('LAND-001', 'Page must have a main landmark',
 '1.3.1', 'A', 'LANDMARKS', 'SERIOUS'),
('LAND-002', 'Landmarks must have unique accessible names where required',
 '2.4.1', 'A', 'LANDMARKS', 'MODERATE'),
-- Tables
('TABLE-001', 'Data tables must identify header cells',
 '1.3.1', 'A', 'TABLES', 'SERIOUS'),
('TABLE-002', 'Tables must have an accessible caption or name where appropriate',
 '1.3.1', 'A', 'TABLES', 'MODERATE'),
-- ARIA / Semantics
('ARIA-001', 'ARIA roles must be valid',
 '4.1.2', 'A', 'ARIA', 'SERIOUS'),
('ARIA-002', 'ARIA attributes must be valid for the assigned role',
 '4.1.2', 'A', 'ARIA', 'SERIOUS');

-- Phase-3 
INSERT INTO web_accessibility_rules
    (rule_code, name, wcag_criterion, wcag_level, category, severity)
VALUES
-- Color / Contrast
('COLOR-001', 'Normal text must meet minimum contrast ratio',
 '1.4.3', 'AA', 'COLOR', 'CRITICAL'),
('COLOR-002', 'Large text must meet minimum contrast ratio',
 '1.4.3', 'AA', 'COLOR', 'SERIOUS'),
('COLOR-003', 'User interface components must have sufficient contrast',
 '1.4.11', 'AA', 'COLOR', 'SERIOUS'),
-- Keyboard
('KEY-001', 'Interactive elements must be keyboard accessible',
 '2.1.1', 'A', 'KEYBOARD', 'CRITICAL'),
('KEY-002', 'Keyboard focus must be visible',
 '2.4.7', 'AA', 'KEYBOARD', 'SERIOUS'),
('KEY-003', 'Page must not contain a keyboard trap',
 '2.1.2', 'A', 'KEYBOARD', 'CRITICAL'),
-- Bypass
('BYPASS-001', 'Page must provide a mechanism to bypass repeated content',
 '2.4.1', 'A', 'NAVIGATION', 'SERIOUS');

ALTER TABLE web_accessibility_scans ADD COLUMN crawl_frequency VARCHAR(50);
ALTER TABLE web_accessibility_scans ADD COLUMN authentication_required BOOL NOT NULL DEFAULT 0;
ALTER TABLE web_accessibility_scans ADD COLUMN authentication_type VARCHAR(50);
ALTER TABLE web_accessibility_scans ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE web_accessibility_issues ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE web_accessibility_rules ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE web_accessibility_issues ADD COLUMN times_seen INTEGER NOT NULL DEFAULT 1;
ALTER TABLE web_accessibility_issues ADD COLUMN last_seen_scan_id BIGINT;
ALTER TABLE web_accessibility_issues ADD COLUMN resolved_at TIMESTAMP NULL;
ALTER TABLE web_accessibility_issues ADD COLUMN resolved_in_scan_id BIGINT;