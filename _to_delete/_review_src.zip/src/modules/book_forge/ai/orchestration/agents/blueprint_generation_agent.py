"""BlueprintGenerationAgent — RAG generation of the book blueprint.

The single owner of blueprint *generation*. Given the retrieved context and the
project metadata already on the state, it:

    project metadata + retrieved chunks
        -> render the versioned generation prompt (Prompt Engine)
        -> LLM call wrapped in guardrails (sanitise in, repair/validate JSON out)
        -> structured blueprint written back onto the state

The graph decides *what happens next* (review, revise, end); this agent only
produces the blueprint. Retrieval is a separate concern (RetrieveKnowledgeNode).
"""
import json
from typing import Any, Dict, List, Optional

from src.core.config import settings
from src.modules.book_forge.ai.foundation.llm.models import (
    LLMMessage,
    LLMRequest,
    LLMRole,
)
from src.modules.book_forge.ai.foundation.llm.services.llm_service import llm_service
from src.modules.book_forge.ai.foundation.llm.utils.model_mapping import provider_for_model
from src.modules.book_forge.ai.foundation.prompts.repositories import PromptRepository
from src.modules.book_forge.ai.intelligence.guardrails.models import GuardrailRequest
from src.modules.book_forge.ai.intelligence.guardrails.policies import (
    PromptInjectionPolicy,
)
from src.modules.book_forge.ai.intelligence.guardrails.services.guardrail_service import (
    GuardrailService,
)

# Blueprint content is the publisher's OWN educational material and the output is a
# chapter outline, so PII scanning here only yields false positives (dates, year
# ranges, or a contact number inside an uploaded syllabus/PYQ) and would block
# legitimate book planning. We keep prompt-injection protection (against malicious
# retrieved content); output validation (toxicity, JSON shape) runs regardless.
_guardrail = GuardrailService(policies=[PromptInjectionPolicy()])
from src.modules.book_forge.ai.orchestration.agents.base_agent import BaseAgent
from src.modules.book_forge.ai.orchestration.blueprint_context import BlueprintContext
from src.modules.book_forge.ai.orchestration.workflow_state import BlueprintState

GENERATION_TEMPLATE = "blueprint_generation"

# Top-level keys the generated JSON must contain (guardrail shape check).
BLUEPRINT_SHAPE = {
    "title": "",
    "description": "",
    "target_audience": "",
    "estimated_length": 0,
    "chapters": [],
}

# Guardrail rules that are genuine SAFETY concerns and MUST block generation.
# Everything else the guardrail can flag (notably ``valid_json`` / structural
# checks) is a *format* concern that repair + our own parse/validation recover
# from — those must NOT hard-fail a blueprint we can successfully parse. Some
# models (e.g. gpt-4o) wrap JSON in ```json fences, which trips ``valid_json`` on
# the raw text even though the payload is perfectly good once unwrapped.
_SAFETY_RULES = {
    "prompt_injection",
    "unsafe_instructions",
    "toxic_content",
    "PII",
    "pii",
}


def _strip_code_fences(text: str) -> str:
    """Remove a leading ```json / ``` fence and its closing ``` if present.

    LLMs frequently wrap JSON output in a Markdown code fence despite being told
    not to. Stripping it here keeps the raw output clean so JSON validation and
    parsing both see a plain object.
    """
    if not text:
        return text
    stripped = text.strip()
    if stripped.startswith("```"):
        # Drop the opening fence line (``` or ```json) ...
        newline = stripped.find("\n")
        if newline != -1:
            stripped = stripped[newline + 1 :]
        # ... and a trailing closing fence.
        if stripped.rstrip().endswith("```"):
            stripped = stripped.rstrip()[:-3]
    return stripped.strip()


def build_prompt_variables(state: BlueprintState) -> Dict[str, Any]:
    """Map the project metadata on the state to the prompt template variables.

    Shared by the query template (retrieval) and the generation template, so the
    two prompts always see the same project context. ``target_audience`` doubles
    as the "standard" (e.g. class-8, class-10, graduate) that the prompt uses to
    calibrate depth, difficulty, and question mix.
    """
    pm = state.project_metadata or {}
    return {
        "book_title": state.title or "",
        "book_subject": pm.get("book_subject") or "",
        "target_audience": state.target_audience or "",
        "book_description": state.description or "",
        "chapter_count": state.chapter_count or 8,
    }


def resolve_template_name(repo, base_name: str, category: Optional[str]) -> str:
    """Pick the category-specific template if it exists, else the generic base.

    e.g. category "history" -> "blueprint_generation_history" when that template
    exists, otherwise "blueprint_generation". This is how one pipeline serves many
    book types: category selects the template; the standard/audience calibrates it.
    """
    if category:
        slug = str(category).strip().lower().replace(" ", "_").replace("-", "_")
        if slug and repo.get_template_by_name(f"{base_name}_{slug}") is not None:
            return f"{base_name}_{slug}"
    return base_name


class BlueprintGenerationAgent(BaseAgent[BlueprintState]):
    """Generate the book blueprint from retrieved context + project metadata."""

    name = "Blueprint Generation Agent"
    step = "generate_blueprint"

    def __init__(self, *, context: BlueprintContext) -> None:
        super().__init__()
        self._context = context

    def execute(self, state: BlueprintState) -> None:
        context = self._context

        # 1) Resolve the generation template by the project's category (falls back
        #    to the generic template), then render it with metadata + retrieved
        #    context. target_audience carries the "standard" for calibration.
        repo = PromptRepository(context.db)
        category = (state.project_metadata or {}).get("category")
        template_name = resolve_template_name(repo, GENERATION_TEMPLATE, category)

        variables = build_prompt_variables(state)
        variables["retrieved_context"] = _format_retrieved(state.retrieved_chunks)
        variables["questions_per_chapter"] = settings.blueprint_questions_per_chapter
        variables["sme_emphasis"] = (state.sme_emphasis or "").strip() or "(none provided)"
        rendered = context.prompt_service.render_prompt(
            template_name, variables
        ).rendered_text

        # 2) Model params come from the versioned generation template; route to the
        #    provider that OWNS the model (e.g. gpt-* -> OpenAI).
        template = repo.get_template_by_name(template_name)
        version = repo.get_active_version(template.id) if template else None
        model = version.model if version else "claude-haiku-4-5-20251001"
        temperature = version.temperature if version else 0.3
        max_tokens = (version.max_tokens if version else None) or 4000
        provider = provider_for_model(model)

        # 3) Call the LLM through guardrails. Capture raw output (GuardrailResponse
        #    only exposes modified_output).
        holder: Dict[str, str] = {}

        def _llm(prompt_text: str) -> str:
            result = llm_service.generate(
                LLMRequest(
                    model=model,
                    messages=[LLMMessage(role=LLMRole.USER, content=prompt_text)],
                    max_tokens=max_tokens,
                    temperature=temperature,
                    project_id=state.project_id,
                ),
                provider=provider,
            )
            # Some models wrap JSON in a Markdown fence; strip it so the raw
            # output the guardrail validates is a plain JSON object.
            content = _strip_code_fences(result.content)
            holder["raw"] = content
            return content

        guard = _guardrail.run(
            GuardrailRequest(
                prompt=rendered,
                operation="generate",
                llm_provider=provider.value,
            ),
            llm=_llm,
            json_shape=BLUEPRINT_SHAPE,
            repair=True,
            raise_on_violation=False,
        )

        # Prefer the repaired output (the guardrail's JSON repair unwraps fences /
        # fixes minor JSON issues); fall back to the raw model text.
        final_text = guard.modified_output or holder.get("raw")

        # Only GENUINE safety violations block. A JSON-format flag (valid_json)
        # is recoverable: the repair step already produced clean JSON, and we
        # parse + validate the structure ourselves below. Blocking on it would
        # discard a perfectly good blueprint (this is what caused gpt-4o's fenced
        # output to be rejected with a false "valid_json" policy violation).
        safety_rules = sorted(
            {v.rule for v in guard.violations if v.rule in _SAFETY_RULES}
        )
        if safety_rules:
            # Structured marker so the entry-point service can raise a
            # PolicyViolationException and surface a clear "Policy violated" response.
            state.metadata["policy_violation"] = {
                "rules": safety_rules,
                "message": "Policy violated. Guardrail blocked",
            }
            state.fail(f"Policy violated. Guardrail blocked: {safety_rules}")
            return
        if not final_text:
            state.fail("Blueprint generation produced no output.")
            return

        # 4) Parse and validate the structured blueprint, then write it onto the state.
        parsed = _parse_blueprint(final_text)
        if not isinstance(parsed, dict) or not isinstance(parsed.get("chapters"), list):
            state.fail("Blueprint output was not valid JSON with a 'chapters' list.")
            return

        chapters = parsed.get("chapters", [])
        issues = _chapter_issues(chapters)
        if issues:
            state.fail(
                "Blueprint chapters failed validation: " + "; ".join(issues[:5])
            )
            return

        state.title = parsed.get("title") or state.title
        state.description = parsed.get("description") or state.description
        state.target_audience = parsed.get("target_audience") or state.target_audience
        state.chapters = chapters
        state.estimated_length = parsed.get("estimated_length") or (
            len(state.chapters) * 20
        )
        state.add_message(
            "assistant",
            f"Generated a blueprint with {len(state.chapters)} chapter(s).",
        )


def _parse_blueprint(text: str) -> Any:
    """Parse JSON, falling back to the guardrail JSON-repair processor."""
    try:
        return json.loads(text)
    except Exception:  # noqa: BLE001 - fall back to repair
        return _guardrail.repair_json(text)


def _chapter_issues(chapters: List[Any]) -> List[str]:
    """Validate the core chapter contract (shared by v1 and v2 output).

    Enforces the fields every chapter must have; the richer v2 fields
    (key_concepts, difficulty_level, assessment_plan, ...) are accepted when
    present but not required here, so a good outline is never rejected over an
    optional field.
    """
    issues: List[str] = []
    if not chapters:
        return ["no chapters were produced"]
    for index, chapter in enumerate(chapters):
        if not isinstance(chapter, dict):
            issues.append(f"chapter[{index}] is not an object")
            continue
        num = chapter.get("chapter_number", index + 1)
        for field in ("chapter_number", "title", "summary"):
            if not chapter.get(field):
                issues.append(f"chapter {num}: missing '{field}'")
        for field in ("covered_topics", "learning_objectives"):
            value = chapter.get(field)
            if not isinstance(value, list) or not value:
                issues.append(f"chapter {num}: '{field}' must be a non-empty list")
    return issues


def _format_retrieved(chunks: List[Dict[str, Any]]) -> str:
    """Turn retrieved chunks into a numbered, source-attributed context block."""
    if not chunks:
        return "(no source material was retrieved for this project)"
    parts = []
    for i, chunk in enumerate(chunks, start=1):
        doc = chunk.get("document_id")
        parts.append(f"--- Source {i} (document {doc}) ---\n{chunk.get('text', '')}")
    return "\n\n".join(parts)
