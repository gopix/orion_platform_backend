"""Friendly, end-user prompt management for blueprint generation.

A publisher never sees Jinja, JSON, model settings, or version numbers. They edit
one plain-English *guidance* box per book type. This service wraps that guidance
in the fixed scaffold (variable plumbing + calibration + the strict JSON output
contract), versions it, and activates it.

    guidance (plain English)  ->  compose()  ->  full template
                                                     -> new version -> active

Book types map to templates by category:
    "default"/""      -> blueprint_generation           (the generic prompt)
    "history"         -> blueprint_generation_history
    "<category>"      -> blueprint_generation_<slug>

The generation pipeline already resolves these per project category, so activating
a book-type prompt here changes how that category's books are generated.
"""
from typing import Any, Dict, List, Optional

from jinja2 import Environment, StrictUndefined
from sqlalchemy.orm import Session

from src.modules.book_forge.ai.foundation.prompts.models import (
    PromptStatus,
    PromptTemplate,
    PromptVariable,
    PromptVersion,
    VariableType,
    VersionStatus,
)
from src.modules.book_forge.ai.foundation.prompts.repositories import PromptRepository
from src.modules.book_forge.services import category_service

BASE_TEMPLATE = "blueprint_generation"
_DEFAULT_MODEL = "gpt-4o-mini"

# Guidance is stored inside the composed template between these markers, so it can
# be edited again later (and it travels with the version, so revert restores it).
_GUIDANCE_HEADER = "BOOK-TYPE GUIDANCE (follow this for structure, emphasis, and assessment style):"
_GUIDANCE_FOOTER = "[END OF BOOK-TYPE GUIDANCE]"

# The declared variables every blueprint template uses.
_VARIABLES = [
    ("book_title", VariableType.STRING, True),
    ("book_subject", VariableType.STRING, False),
    ("target_audience", VariableType.STRING, False),
    ("book_description", VariableType.STRING, False),
    ("chapter_count", VariableType.INTEGER, False),
    ("questions_per_chapter", VariableType.INTEGER, False),
    ("retrieved_context", VariableType.STRING, True),
]

DEFAULT_GUIDANCE = (
    "Organize chapters from foundational to advanced for the target audience. "
    "For each chapter plan a balanced mix of question types appropriate to the "
    "subject and standard, weighting the number of questions by each topic's exam "
    "weightage. Keep language and difficulty appropriate to the target audience."
)

_SCAFFOLD_TOP = """\
You are an expert book architect and assessment designer. Using ONLY the source
material provided below, design a detailed, author-ready chapter blueprint for the
following book.

BOOK REQUIREMENTS
Title: {{ book_title }}
Subject: {{ book_subject }}
Target Audience / Standard: {{ target_audience }}
Description: {{ book_description }}
Desired number of chapters: {{ chapter_count }}
Target questions per chapter (average): {{ questions_per_chapter }}

SOURCE MATERIAL (retrieved from the project's knowledge base)
{{ retrieved_context }}

CALIBRATE TO THE STANDARD
- The target audience "{{ target_audience }}" is the STANDARD. Calibrate depth,
  vocabulary, difficulty, and the question mix to it.
"""

_SCAFFOLD_BOTTOM = """\
INSTRUCTIONS
- Base the blueprint strictly on the source material; do NOT invent topics it does
  not support. {{ chapter_count }} is the MAXIMUM number of chapters, not a target:
  produce only as many chapters as the syllabus genuinely justifies (roughly one per
  distinct syllabus unit/topic), which may be FEWER than {{ chapter_count }}. Never
  invent, split, or pad topics merely to reach {{ chapter_count }}; the chapter
  count must be justified by the syllabus.
- Follow the BOOK-TYPE GUIDANCE above for chapter structure, emphasis, and the
  style/mix of assessment questions.
- WEIGHTAGE: assign each chapter a "weight" from 1 (light) to 5 (heavy) that its
  assessment scales from. Decide the weight using the FIRST applicable signal, in
  this priority order:
    1. SME EMPHASIS (authoritative): if an SME emphasis note is given below, follow
       it - emphasized topics/chapters get higher weight, de-emphasized ones lower.
    2. PREVIOUS-YEAR QUESTIONS (PYQ): if the source contains PYQ, derive the weight
       from how often each chapter's topics recur across the years (more frequent =
       higher weight).
    3. EXPLICIT WEIGHTAGE/MARKS TABLE: if the source has one, scale by it.
    4. EVEN: if none of the above are available (e.g. a school syllabus with no PYQ
       and no SME input), give every chapter an equal weight.
  If BOTH SME emphasis and PYQ are present, use both, with SME emphasis taking
  precedence. Then set each chapter's TOTAL number of questions in PROPORTION to its
  weight - as a guide, total_questions is approximately
  {{ questions_per_chapter }} * weight / 3 (so a weight-5 chapter has roughly 2.5x
  the questions of a weight-2 chapter). {{ questions_per_chapter }} is only the
  AVERAGE across chapters, NOT a per-chapter target: individual totals MUST differ
  with weight - it is WRONG to give every chapter the same total (unless rule 4
  EVEN applies). The six by_type counts MUST sum to each chapter's total_questions,
  and by_difficulty MUST sum to the same total.

SME EMPHASIS: {{ sme_emphasis }}
- "by_type" MUST use exactly these keys: mcq_single_correct, multiple_correct,
  numerical_value, assertion_reason, fill_in_the_blanks, previous_year_questions.
- "by_difficulty" MUST use exactly these keys: easy, medium, hard.
- "total_questions" MUST equal the sum of the by_type counts.
- Return ONLY valid JSON (no markdown, no prose) matching EXACTLY this shape:
{
  "title": "string",
  "description": "string",
  "target_audience": "string",
  "estimated_length": 0,
  "chapters": [
    {
      "chapter_number": 1,
      "title": "string",
      "summary": "string",
      "covered_topics": ["string"],
      "learning_objectives": ["string"],
      "key_concepts": ["string"],
      "difficulty_level": "foundational | intermediate | advanced",
      "weight": 3,
      "focus_areas": ["string"],
      "assessment_plan": {
        "by_type": {
          "mcq_single_correct": 0, "multiple_correct": 0, "numerical_value": 0,
          "assertion_reason": 0, "fill_in_the_blanks": 0, "previous_year_questions": 0
        },
        "by_difficulty": { "easy": 0, "medium": 0, "hard": 0 },
        "total_questions": 0
      }
    }
  ]
}"""

_SAMPLE_VARS = {
    "book_title": "Sample Book",
    "book_subject": "Sample Subject",
    "target_audience": "Class 10",
    "book_description": "A sample description.",
    "chapter_count": 8,
    "questions_per_chapter": 40,
    "retrieved_context": "(sample source material from the project's documents)",
    "sme_emphasis": "(none provided)",
}


# ------------------------------------------------------------------ #
# Compose / extract                                                  #
# ------------------------------------------------------------------ #
def compose_template(guidance: str) -> str:
    """Wrap plain guidance in the fixed scaffold to form the full template text."""
    guidance = (guidance or "").strip() or DEFAULT_GUIDANCE
    return (
        f"{_SCAFFOLD_TOP}\n{_GUIDANCE_HEADER}\n{guidance}\n{_GUIDANCE_FOOTER}\n\n"
        f"{_SCAFFOLD_BOTTOM}"
    )


def extract_guidance(template_text: Optional[str]) -> str:
    """Pull the plain guidance back out of a composed template (or '' if absent)."""
    text = template_text or ""
    if _GUIDANCE_HEADER in text and _GUIDANCE_FOOTER in text:
        return text.split(_GUIDANCE_HEADER, 1)[1].split(_GUIDANCE_FOOTER, 1)[0].strip()
    return ""


def _template_name(category: Optional[str]) -> str:
    slug = (category or "").strip().lower().replace(" ", "_").replace("-", "_")
    if not slug or slug in ("default", "generic", "base"):
        return BASE_TEMPLATE
    return f"{BASE_TEMPLATE}_{slug}"


def _category_label(template_name: str) -> str:
    if template_name == BASE_TEMPLATE:
        return "default"
    return template_name[len(BASE_TEMPLATE) + 1 :]


# ------------------------------------------------------------------ #
# Operations                                                         #
# ------------------------------------------------------------------ #
def list_book_types(db: Session) -> List[Dict[str, Any]]:
    """List every book-type prompt with a friendly summary (incl. category_id)."""
    repo = PromptRepository(db)
    out: List[Dict[str, Any]] = []
    for template in repo.list_templates(name_prefix=BASE_TEMPLATE):
        active = repo.get_active_version(template.id) if template.id else None
        label = _category_label(template.name)
        category = category_service.get_category(db, label) if label != "default" else None
        out.append(
            {
                "category_id": category.id if category else None,
                "category_name": label,
                "active_version": active.version if active else None,
                "updated_at": template.updated_at,
                "has_guidance": bool(active and extract_guidance(active.template_text)),
            }
        )
    return out


def get_guidance(db: Session, category: Optional[str]) -> Dict[str, Any]:
    """Return the current plain-English guidance for a book type."""
    repo = PromptRepository(db)
    name = _template_name(category)
    template = repo.get_template_by_name(name)
    active = repo.get_active_version(template.id) if template else None
    guidance = extract_guidance(active.template_text) if active else ""
    return {
        "category": _category_label(name),
        "guidance": guidance or DEFAULT_GUIDANCE,
        "active_version": active.version if active else None,
        "exists": template is not None,
    }


def set_guidance(
    db: Session,
    category: Optional[str],
    guidance: str,
    *,
    created_by: Optional[int] = None,
    model: Optional[str] = None,
) -> Dict[str, Any]:
    """Save new guidance: compose -> new version -> activate. Creates the
    book-type template on first use."""
    repo = PromptRepository(db)
    name = _template_name(category)
    template_text = compose_template(guidance)

    # Registering a prompt for a category also registers the category itself, so
    # it becomes selectable when creating projects. (The generic/default template
    # is not a selectable category.)
    if name != BASE_TEMPLATE:
        category_service.upsert_category(db, category)

    template = repo.get_template_by_name(name)
    if template is None:
        template = repo.create_template(
            PromptTemplate(
                name=name,
                category=_category_label(name),
                description=f"Blueprint generation prompt for '{_category_label(name)}' books.",
                status=PromptStatus.ACTIVE,
                created_by=created_by,
            )
        )
        repo.create_variables(
            template.id,
            [PromptVariable(name=n, type=t, required=r) for n, t, r in _VARIABLES],
        )

    resolved_model = (model or "").strip() or _inherited_model(repo)
    versions = repo.get_versions(template.id)
    next_version = max((v.version for v in versions), default=0) + 1
    repo.create_version(
        PromptVersion(
            template_id=template.id,
            version=next_version,
            template_text=template_text,
            model=resolved_model,
            temperature=0.3,
            max_tokens=8000,
            status=VersionStatus.DRAFT,
            created_by=created_by,
        )
    )
    repo.activate_version(template.id, next_version)
    return {
        "category": _category_label(name),
        "active_version": next_version,
        "model": resolved_model,
        "guidance": (guidance or "").strip() or DEFAULT_GUIDANCE,
    }


def preview(db: Session, category: Optional[str], guidance: str) -> Dict[str, Any]:
    """Render the composed prompt with sample values — no LLM, no tokens spent."""
    composed = compose_template(guidance)
    rendered = Environment(undefined=StrictUndefined).from_string(composed).render(
        **_SAMPLE_VARS
    )
    return {
        "category": _category_label(_template_name(category)),
        "rendered_prompt": rendered,
    }


def revert(db: Session, category: Optional[str]) -> Dict[str, Any]:
    """Roll back to the previous version for a book type."""
    repo = PromptRepository(db)
    name = _template_name(category)
    template = repo.get_template_by_name(name)
    if template is None:
        return {"category": _category_label(name), "active_version": None, "reverted": False}

    versions = sorted(repo.get_versions(template.id), key=lambda v: v.version)
    if len(versions) < 2:
        return {
            "category": _category_label(name),
            "active_version": versions[-1].version if versions else None,
            "reverted": False,
        }
    previous = versions[-2].version
    repo.activate_version(template.id, previous)
    return {
        "category": _category_label(name),
        "active_version": previous,
        "reverted": True,
    }


def _inherited_model(repo: PromptRepository) -> str:
    """Reuse the base template's active model so the publisher never sets one."""
    base = repo.get_template_by_name(BASE_TEMPLATE)
    active = repo.get_active_version(base.id) if base else None
    return (active.model if active and active.model else _DEFAULT_MODEL)
