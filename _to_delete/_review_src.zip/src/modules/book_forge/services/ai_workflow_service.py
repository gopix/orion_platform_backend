"""AI workflow service — the entry point into the AI Orchestration layer.

This service is intentionally thin. It does NOT orchestrate AI (no Parser, no
Chunking, no Embeddings, no Pinecone). Its only job is to:

1. load the project and its documents,
2. build the initial ``ProcessingWorkflowState``,
3. invoke the Book Processing Orchestrator,
4. return the final processing result.

From there everything happens inside Orchestration:

    AIWorkflowService
        -> BookProcessingOrchestrator
        -> book_processing graph -> nodes -> agents -> AI services

Changing *what* runs (add OCR, parallel stages, review loop-backs) is a change to
the graph — this service never moves.
"""
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from src.core.config import settings
from src.core.logger import get_logger
from src.modules.book_forge.ai.foundation.prompts.services import build_prompt_service
from src.modules.book_forge.ai.intelligence.guardrails.exceptions import (
    PolicyViolationException,
)
from src.modules.book_forge.ai.orchestration.blueprint_context import BlueprintContext
from src.modules.book_forge.ai.orchestration.orchestrators import (
    blueprint_orchestrator,
    book_processing_orchestrator,
)
from src.modules.book_forge.ai.orchestration.workflow_state import (
    BlueprintState,
    ProcessingWorkflowState,
    WorkflowStatus,
)
from src.modules.book_forge.services import (
    blueprint_service,
    document_service,
    project_service,
)

logger = get_logger(__name__)


def process_project(db: Session, 
    project_id: int,
    documents: Optional[List[Any]] = None,
) -> Dict[str, Any]:
    """Start the Book Processing workflow for a project and return its result."""

    # 1) Load the project and its documents.
    project_service.get_project(db, project_id)
    if documents is None:
        documents = document_service.get_documents(db, project_id=project_id,
                                                     skip=0, limit=1000)

    # 2) Build the initial workflow state (data only — no AI logic here).
    state = ProcessingWorkflowState(project_id=project_id,
                                     documents=[_descriptor(document) for document in documents],
                                    )

    # 3) Hand off to the Orchestration layer.
    final_state = book_processing_orchestrator.execute(state)

    # 4) Return a summary of the final state.
    return _summarize(final_state)


def _descriptor(document: Any) -> Dict[str, Any]:
    """A lightweight, serialisable reference the workflow carries per document."""
    return {
        "id": getattr(document, "id", None),
        "project_id": getattr(document, "project_id", None),
        "filename": getattr(document, "original_filename", None),
        "file_path": getattr(document, "file_path", None),
    }


def _summarize(state: ProcessingWorkflowState) -> Dict[str, Any]:
    graph = state.knowledge_graph
    return {
        "run_id": state.run_id,
        "project_id": state.project_id,
        "status": state.status.value,
        "documents": len(state.documents),
        "parsed_documents": len(state.parsed_documents),
        "graph_nodes": len(graph.nodes) if graph else 0,
        "graph_edges": len(graph.edges) if graph else 0,
        "chunks": len(state.chunks),
        "embeddings": len(state.embeddings),
        "vector_ids": len(state.vector_ids),
        "skipped": state.skipped,
        "errors": state.errors,
    }


def generate_blueprint(
    db: Session,
    project_id: int,
    created_by: Optional[int] = None,
    sme_emphasis: Optional[str] = None,
) -> Dict[str, Any]:
    """Generate (and persist) a book blueprint for a project via the RAG graph.

    Loads the project, seeds a ``BlueprintState`` from its metadata, runs the
    blueprint graph (retrieve -> generate -> review), and persists a new
    versioned blueprint row. Returns a summary of the run.
    """
    # 1) Load the project and seed the initial state from its metadata.
    project = project_service.get_project(db, project_id)
    state = BlueprintState(
        project_id=project_id,
        title=project.book_title,
        description=project.book_description,
        target_audience=project.target_audience,
        chapter_count=project.chapter_count,
        project_metadata=project.to_dict(),
        sme_emphasis=sme_emphasis,
    )

    # 2) Build the per-request context (DB-backed Prompt Engine + top_k).
    context = BlueprintContext(
        db=db,
        prompt_service=build_prompt_service(db),
        top_k=settings.blueprint_top_k,
        created_by=created_by,
    )

    # 3) Run the blueprint workflow.
    final_state = blueprint_orchestrator.generate(state, context=context)

    # 3a) A guardrail block is an explicit, reportable outcome — raise it so the
    # caller is told clearly (rather than getting a silent "failed" summary).
    violation = final_state.metadata.get("policy_violation")
    if violation:
        raise PolicyViolationException(
            violation.get("message", "Policy violated. Guardrail blocked"),
            details={"rules": violation.get("rules", [])},
        )

    # 4) Persist a new versioned blueprint (only on a successful, non-empty run).
    record = None
    if final_state.status != WorkflowStatus.FAILED and final_state.chapters:
        review = final_state.metadata.get("review", {})
        status_value = "approved" if review.get("approved") else "generated"
        blueprint_json = {
            "title": final_state.title,
            "description": final_state.description,
            "target_audience": final_state.target_audience,
            "estimated_length": final_state.estimated_length,
            "chapters": final_state.chapters,
        }
        record = blueprint_service.create_blueprint(
            db,
            project_id=project_id,
            blueprint_json=blueprint_json,
            title=final_state.title,
            description=final_state.description,
            status=status_value,
            created_by=created_by,
        )

    return _summarize_blueprint(final_state, record)


def _summarize_blueprint(state: BlueprintState, record) -> Dict[str, Any]:
    return {
        "run_id": state.run_id,
        "project_id": state.project_id,
        "status": state.status.value,
        "blueprint_id": record.id if record else None,
        "version": record.version if record else None,
        "blueprint_status": record.status if record else None,
        "title": state.title,
        "chapters": len(state.chapters),
        "retrieved_chunks": len(state.retrieved_chunks),
        "review": state.metadata.get("review"),
        "errors": state.errors,
    }
